# Exercise 5.1
day, high_temperature = ('Monday', 87, 65) 

numbers = [1, 2, 3, 4, 5]
numbers[10] 

name = 'amanda'
name[0] = 'A' 

numbers = [1, 2, 3, 4, 5]
numbers[3.4] 

student_tuple = ('Amanda', 'Blue', [98, 75, 87]) 
student_tuple[0] = 'Ariana' 

('Monday', 87, 65) + 'Tuesday' 

'A' += ('B', 'C') 

x = 7 
del x
print(x) 

numbers = [1, 2, 3, 4, 5]
numbers.index(10) 

numbers = [1, 2, 3, 4, 5]
numbers.extend(6, 7, 8) 

numbers = [1, 2, 3, 4, 5]
numbers.remove(10) 

values = []
values.pop() 

##########################################################################
# (C) Copyright 2019 by Deitel & Associates, Inc. and                    #
# Pearson Education, Inc. All Rights Reserved.                           #
#                                                                        #
# DISCLAIMER: The authors and publisher of this book have used their     #
# best efforts in preparing the book. These efforts include the          #
# development, research, and testing of the theories and programs        #
# to determine their effectiveness. The authors and publisher make       #
# no warranty of any kind, expressed or implied, with regard to these    #
# programs or to the documentation contained in these books. The authors #
# and publisher shall not be liable in any event for incidental or       #
# consequential damages in connection with, or arising out of, the       #
# furnishing, performance, or use of these programs.                     #
##########################################################################
