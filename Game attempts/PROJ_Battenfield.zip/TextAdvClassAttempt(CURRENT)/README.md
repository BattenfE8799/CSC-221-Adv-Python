# textadv21 
# Python text adventure framework

-Working on if statements for shelter door(so they have to have key to get it). 

ToDO
- if statement when in shelter door, after it is unlocked if theyre sure they want to go in, 
--when they dont have all the people rescued, etc

- if statements to get people, need items. Can only carry 1 thing at a time.


