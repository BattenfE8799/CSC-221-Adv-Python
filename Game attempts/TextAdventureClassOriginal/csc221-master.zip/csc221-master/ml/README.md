# README.md
# csc 221 machine learning examples

# notes on windows setup
you should probably choose to either run everything under Anaconda (Spyder / Jupyter notebooks) 
or in a virtualenv (editor of your choice, python console at the command line in your venv)

to setup anaconda appropriately, on Windows use 'anaconda console'. 
note that this effectively launches the anaconda venv.
inside this you can install the needed modules
for example
(launch anaconda console)
pip install tensorflow
pip install keras

-----
first pass: confirm modules are installed, load mnist data, view samples
