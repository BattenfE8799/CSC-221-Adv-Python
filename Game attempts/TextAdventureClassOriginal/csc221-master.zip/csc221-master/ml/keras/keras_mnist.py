# keras mnist example

