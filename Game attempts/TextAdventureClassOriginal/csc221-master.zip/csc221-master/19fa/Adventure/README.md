#Adventure

The CSC 221 text adventure project

TODO
[ ] Build house data
[ ] Text Parser
