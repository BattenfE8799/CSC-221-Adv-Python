# coding: utf-8
from textblob import TextBlob
text = "Today is a beautiful day. Tomorrow looks like bad weather."
blob = TextBlob(text)
blob
exercise_blob = TextBlob("This is a TextBlob")
exercise_blob
blob.sentences
blob.words
ex = TextBlob("My old computer is slow. My new one is fast.")
ex.sentences
ex.words
blob
blob.tags
TextBlob("My dog is cute").tags
blob
blob.noun_phrases
TextBlob("The red brick factory is for sale").noun_phrases
blob
blob.sentiment
get_ipython().run_line_magic('precision', '3')
blob.sentiment.polarity
blob.sentiment.subjectivity
for sentence in blob.sentences:
    print(sentence.sentiment)
    
from textblob import Sentence
Sentence("The food is not good.").sentiment
Sentence("The movie was not bad.").sentiment
Sentence("The movie was excellent!").sentiment
from textblob.sentiments import NaiveBayesAnalyzer
blob = TextBlob(text, analyzer=NaiveBayersAnalyzer())
blob = TextBlob(text, analyzer=NaiveBayesAnalyzer())
blob
blob.sentiment
for sentence in blob.sentences:
    print(sentence.sentiment)
    
text = (
"The movie was excellent!")
exblob = TextBlob(text, analyzer=NaiveBayesAnalyzer())
exblob.sentiment
blob.detect_language()
