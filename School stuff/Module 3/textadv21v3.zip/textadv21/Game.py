# CSC 221
# Text Adventure
# norrisa
# 10/1/21

from Room import Room
#import Player


"""
Version history:
    v1 - built using Room references (basically a graph). 
        downside: you have to create all rooms, then link
        them together afterwards.
        
    v2 - used constant room IDs to make it possible to add
        and link rooms in one pass. 
        downside: "this looks like BASIC" (from the peanut gallery)
        
    v3 - realization: if the Room names are unique, that's a
        unique ID. I therefore changed
        the container for all Rooms to be a dictionary --
        now it's easy enough to look up the room by name.


"""

class Game:
    """
    The Game class organizes all game data in a central location.
    Usage:
    - Set up game using your choice of room configurations
      (TODO: Read these from a file in future)
    - call loop()
    """

    def __init__(self):
        """ Initialize object (with no rooms) """
        #self.player = player.Player()
        self.rooms = { } # stored in dictionary
        
        

    def __str__(self):
        pass

    def __repr__(self):
        pass


    def setup(self):
        """ setup(): create a graph of rooms for play. """
        # just a test -- needs work
        
        pass

    def loop(self):
        """ loop(): the main game loop.
        Continues until the user quits. """
        
        pass

    def end(self):
        """ finish game, inform user of score and turns played. """
        pass
    






def main():
    game = Game()
    game.setup()
    game.loop()
    game.end()


if __name__ == "__main__":
    main()
