# Creating and manipulating array
# 9/7/2021
# CSC221 M1HW1 – Array Manipulations
# Elizabeth Battenfield
import numpy as np
import sys


def main():
    """ menu based program that creates array and manipulates it"""
    array1 = []
    menu(array1)
    

def menu(array1):
    #create menu look
    """Menu loop"""
    print("MENU")
    print("_________________________________")
    print()
    print("  1) Create a 3-by-3 Array")
    print("  2) Display cube Values for elements in array")
    print("  3) Add 7 to every element and display result")
    print("  4) Multiply elements by 6 and display result")
    print("  5) Exit")
    print()
    menuChoice = int(input())
    #what user choice does
    if menuChoice == 1: 
        array1 = createArray()
    elif menuChoice == 2:
        displayCubeValues(array1)
    elif menuChoice == 3:
        addSeven(array1)
    elif menuChoice == 4:
        multiplySix(array1)
    elif menuChoice == 5:
        sys.exit() #if chose 5 end program
    else:
        #if entered wrong input send back to try again
        print("Error: Invalid entry. Please try again.")
        menu(array1)

    #create 3by3 array of 2-18 Evens
def createArray():
    """Creates 3-by-3 Array"""
    array1 = np.arange(2,19,2).reshape(3,3)
    #display array without brackets
    print()
    for x in range(3):
        for y in range (3):
            print(array1[x][y], end = " ")
        print()
    print()
    menu(array1)
    
def displayCubeValues(array1):
    """Displays cube values for elements in array"""
    print()
    #find out if array is empty
    is_empty = len(array1)
    if is_empty == 0:
        print()
        print("There is no array. Please create one.")
        menu(array1) #if empty send to main menu again
    else:
        print()
        #create second array to "copy" first one and cube elements in array and display
        array2 = array1 **3
        for x in range(3):
            for y in range(3):
                print(array2[x][y], end = " ")
            print()
    print()
    menu(array1)
        


def addSeven(array1):
    """Add 7 to every element and display result"""
    print()
    #find if array is empty and if so send back to menu
    is_empty = len(array1)
    if is_empty == 0:
        print()
        print("There is no array. Please create one.")
        menu(array1)
    else:
        #create second array to "copy" first one and add 7 to elements in array and display
        array2 = array1 + 7
        print()
        for x in range(3):
            for y in range(3):
                print(array2[x][y], end = " ")
            print()
    print()
    menu(array1)
    

def multiplySix(array1):
    """Multiply elements by 6 and display result"""
    print()
        #find if array is empty and if so send back to menu
    is_empty = len(array1)
    if is_empty == 0:
        print()
        print("There is no array. Please create one.")
        menu(array1)
    else:
        #create second array to "copy" first one and times 6 to elements in array and display
        array2 = array1 * 6
        print()
        for x in range(3):
            for y in range(3):
                print(array2[x][y], end = " ")
            print()
    print()
    menu(array1)
    
if __name__ == "__main__":
    main()